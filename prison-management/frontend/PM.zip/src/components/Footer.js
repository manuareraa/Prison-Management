import React from "react";

function Footer(props) {
  return (
    <footer className="custom-footer bg-prison-blue text-white">For any issues please contact your admin at: admin@prisonmanagement.com</footer>
  );
}

export default Footer;
